<?php

// We use this config file (_tvp_config.php) to track the constants that are used in the tests.
// It contains constants WITHOUT values.
// If you want to introduce new config constants, be sure to add them here
// so other developers will know they need to add them in their config file.
// The real config file that has the constants WITH values is tvp_config.php

define('TEST_USERNAME', '');
define('TEST_PASSWORD', '');
define('ADMIN_USERNAME', '');
define('ADMIN_PASSWORD', '');
define('TEST_URL', '');
define('BACKEND_URL', '');

//Credit Card
define('TESTDONOR_CC_USERNAME', '');
define('TESTDONOR_CC_PASSWORD', '');
define('EMAIL_CC', '');
define('EMAIL_PW_CC', '');
define('EMAIL_RECUR_CC', '');
define('EMAIL_PW_RECUR_CC', '');

define('LOCAL_HOMEPAGE_URL', '');

//PayPal - TVP
define('TESTDONOR_PP_USERNAME', '');
define('TESTDONOR_PP_PASSWORD', '');
define('EMAIL_PP', '');
define('EMAIL_PW_PP', '');
define('EMAIL_RECUR_PP', '');
define('EMAIL_PW_RECUR_PP', '');

//PayPal - FBD
define('TESTDONOR_FBD_PP_USERNAME', '');
define('TESTDONOR_FBD_PP_PASSWORD', '');
define('EMAIL_FBD_PP', '');
define('EMAIL_PW_FBD_PP', '');
define('EMAIL_FBD_RECUR_PP', '');
define('EMAIL_PW_FBD_RECUR_PP', '');

define('PAYPAL_MERCHANT_ACCOUNT', '');
define('PAYPAL_MERCHANT_ACCOUNT_PASSWORD', '');
define('PAYPAL_BUYER_ACCOUNT', '');
define('PAYPAL_BUYER_ACCOUNT_PASSWORD', '');
define('PAYPAL_STORE_NAME', "Borislav Zlatanov's Test Store");

