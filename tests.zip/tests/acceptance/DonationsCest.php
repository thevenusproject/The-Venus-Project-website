<?php

/*
 * This test suite contains tests for making donations in different scenario's
 *
 * Note: due to a change in Firefox 43 and/or Selenium 2.48.2, sometimes there are clicks on
 * the Wordpress backend menu located behind the CiviCRM menu. In those situations we use javascript instead.
 */
class DonationsCest {

    // set up form details
    public $form_details = array(
        'amount' => '10.00',
        'credit_card_number' => '4242424242424242',
        'cvv2' => '111',
        'exp_date_m' => 'Feb',
        'exp_date_y' => '2018',
        'billing_first_name' => 'Myfirstname',
        'billing_last_name' => 'Mylastname',
        'billing_street' => 'Mystreet',
        'billing_city' => 'Mycity',
        'billing_country' => 'Australia',
        'billing_country_short' => 'AU',
        'billing_state' => 'Queensland',
        'billing_state_short' => 'ACT',
        'billing_postal_code' => '4020'
    );

    public $messages = array(
        'contrib_status_completed' => 'Completed',
		
		'donation_page_tvp' => array('Note: this donation is not tax-deductible.'),
		
		'donation_page_fbd' => array('This is a tax-deductible donation to Future by Design, a not for profit 501(c)(3) charitable organization.'),
		
        'page_thank_you_msg' => array('Thank you','Thank you for contributing to our ongoing projects. We appreciate that you consider this something worth supporting.','Your help allows us to keep working towards the realization of this social direction.'),
		
        'email_thank_you_msg_tvp' => array('The Venus Project thanks you for your donation.','It has been heartwarming to see the wonderful response to our request for donations. We want to thank you for your very thoughtful donation to our funding drive. Your support will help us to introduce a viable social alternative to a larger audience. Your contribution will make this possible.','No services or goods were provided in exchange for or in connection with this donation.','Thank you again for your generous gift on behalf of The Venus Project.'),
		
		'email_thank_you_msg_fbd' => array('Future by Design thanks you for your donation.','It has been heartwarming to see the wonderful response to our request for donations. We want to thank you for your very thoughtful donation to our funding drive. Your support will help us to introduce a viable social alternative to a larger audience. Your contribution will make this possible.','No services or goods were provided in exchange for or in connection with this donation.','You can keep this letter as written proof for your tax records of your donation to Future By Design, which is a 501(c)(3) not for profit charitable organization.','Thank you again for your generous gift on behalf of Future By Design.','A COPY OF THE OFFICIAL REGISTRATION AND FINANCIAL INFORMATION MAY BE OBTAINED FROM THE DIVISION OF CONSUMER SERVICES BY CALLING TOLL-FREE (800-435-7352) WITHIN THE STATE. REGISTRATION DOES NOT IMPLY ENDORSEMENT, APPROVAL, OR RECOMMENDATION BY THE STATE.','Registration # CH35014'),
		
        'recurring_daily_msg_1' => 'I want to contribute this amount every month.',
        'recurring_monthly_msg' => 'This recurring contribution will be automatically processed every month.',
        'recurring_info_msg' => 'Your initial contribution will be processed once you complete the confirmation step. You will be able to cancel the recurring contribution by following the information that will be included in your email receipt.'
    );

    public function _before(\AcceptanceTester $I)
    {
        $I->amOnUrl(TEST_URL);
        $I->maximizeWindow();
    }

    public function _after(\AcceptanceTester $I)
    {
		$I->pauseExecution();
    }

    /**
     * This code will be executed if a test fails or has errors
     * @param \AcceptanceTester $I
     */
    public function _failed(\Step\Acceptance\Admin $I)
    {
        // $I->amGoingTo('Activate maintanance mode again');
		// $I->logOut();
		// $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
        // $I->activateMaintenanceMode($I);
    }

    // tests
    public function donate_TVP_CreditCard_LoggedIn(
            \Step\Acceptance\Admin $I,
            \Page\Donation $donationPage,
            \Page\CiviCRM $civiCRMPage,
            \Page\Webmail $webmailPage)
    {
        $I->wantTo('Make a donation to TVP with a CreditCard as a logged in user');
        $I->logIn(TESTDONOR_CC_USERNAME, TESTDONOR_CC_PASSWORD);

        $this->makeDonation($I, 'TVP', 'CreditCard', $donationPage, $civiCRMPage, $webmailPage, true, false);
    }

    public function donate_TVP_CreditCard_LoggedOut(
            \Step\Acceptance\Admin $I,
            \Page\Donation $donationPage,
            \Page\CiviCRM $civiCRMPage,
            \Page\Webmail $webmailPage)
    {
        $I->wantTo('Make a donation to TVP with a CreditCard while being logged out');

		//Deactivate the maintenance mode
		// $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
		// $I->deactivateMaintenanceMode($I);

		// $I->logOutAsAdmin();

        $this->makeDonation($I, 'TVP', 'CreditCard', $donationPage, $civiCRMPage, $webmailPage, false, false);

		//Activate the maintenance mode again
		// $I->activateMaintenanceMode($I);
    }
	
	public function donate_TVP_CreditCard_Recur_LoggedOut(
            \Step\Acceptance\Admin $I,
            \Page\Donation $donationPage,
            \Page\CiviCRM $civiCRMPage,
            \Page\Webmail $webmailPage)
    {
        $I->wantTo('Make a recurring donation to TVP with CreditCard while being logged out');
		// $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);

		//For recurring contributions we need the Stripe Webhook to be able to reach our site
		// $I->deactivateMaintenanceMode($I);

		// $I->logOutAsAdmin();

        $this->makeDonation($I, 'TVP', 'CreditCard', $donationPage, $civiCRMPage, $webmailPage, false, true);

		//Activate maintenance mode again
		// $I->activateMaintenanceMode($I);
    }

    public function donate_TVP_PayPal_LoggedIn(
            \Step\Acceptance\Admin $I,
            \Page\Donation $donationPage,
            \Page\CiviCRM $civiCRMPage,
            \Page\Webmail $webmailPage)
    {
        $I->wantTo('Make a donation to TVP with PayPal as a logged in user');
        $I->logIn(TESTDONOR_PP_USERNAME, TESTDONOR_PP_PASSWORD);

        $this->makeDonation($I, 'TVP', 'PayPal', $donationPage, $civiCRMPage, $webmailPage, true, false);
    }

    public function donate_TVP_PayPal_LoggedOut(
            \Step\Acceptance\Admin $I,
            \Page\Donation $donationPage,
            \Page\CiviCRM $civiCRMPage,
            \Page\Webmail $webmailPage)
    {
        $I->wantTo('Make a donation to TVP with PayPal while being logged out');

        //Deactivate the maintenance mode
		// $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
		// $I->deactivateMaintenanceMode($I);

		// $I->logOut();

        $this->makeDonation($I, 'TVP', 'PayPal', $donationPage, $civiCRMPage, $webmailPage, false, false);

		//Activate the maintenance mode again
		// $I->activateMaintenanceMode($I);
    }

    public function donate_TVP_PayPal_Recur_LoggedOut(
            \Step\Acceptance\Admin $I,
            \Page\Donation $donationPage,
            \Page\CiviCRM $civiCRMPage,
            \Page\Webmail $webmailPage)
    {
        $I->wantTo('Make a recurring donation to TVP with PayPal while being logged out');
        // $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);

		//For recurring contributions we need the Stripe Webhook to be able to reach our site
		// $I->deactivateMaintenanceMode($I);

		// $I->logOut();
        $this->makeDonation($I, 'TVP', 'PayPal', $donationPage, $civiCRMPage, $webmailPage, false, true);
        //Activate maintenance mode again
		// $I->activateMaintenanceMode($I);
    }
	
	public function donate_FBD_PayPal_LoggedOut(
			\Step\Acceptance\Admin $I,
            \Page\Donation $donationPage,
            \Page\CiviCRM $civiCRMPage,
            \Page\Webmail $webmailPage)
	{
		$I->wantTo('Make a donation to FBD with PayPal while being logged out');
		
		//Deactivate the maintenance mode
		// $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
		// $I->deactivateMaintenanceMode($I);

		// $I->logOutAsAdmin();

        $this->makeDonation($I, 'FBD', 'PayPal', $donationPage, $civiCRMPage, $webmailPage, false, false);

		//Activate the maintenance mode again
		// $I->activateMaintenanceMode($I);
		
	}
	
	public function donate_FBD_PayPal_Recur_LoggedOut(
            \Step\Acceptance\Admin $I,
            \Page\Donation $donationPage,
            \Page\CiviCRM $civiCRMPage,
            \Page\Webmail $webmailPage)
    {
        $I->wantTo('Make a recurring donation to FBD with PayPal while being logged out');
		
		//Deactivate the maintenance mode
        // $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
		// $I->deactivateMaintenanceMode($I);

		// $I->logOutAsAdmin();
		
        $this->makeDonation($I, 'FBD', 'PayPal', $donationPage, $civiCRMPage, $webmailPage, false, true);
		
		//Activate the maintenance mode again
		// $I->activateMaintenanceMode($I);
    }
	
	public function tryDonateWithIncorrectDetails(
           \Step\Acceptance\Admin $I,
           \Page\Donation $donationPage)
   {
		$I->wantTo('Make a donation attempt with incorrect details');
		
		//Deactivate the maintenance mode
		// $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
		// $I->deactivateMaintenanceMode($I);

		// $I->logOutAsAdmin();
		
		$I->tryDonation($I, $donationPage, $this->form_details);
		
		//Activate the maintenance mode again
		// $I->activateMaintenanceMode($I);
   }

	/**
     *
     * Function to help us create a new assertion without having to wait
	 * for a whole test to execute before we test whether the assertion works
     *
     * Note: set as protected so this won't run when we run the complete test suite
     */
	protected function testAssertion(
			\Step\Acceptance\Admin $I,
			\Page\Donation $donationPage,
			\Page\CiviCRM $civiCRMPage,
			\Page\Webmail $webmailPage)
	{
		$form_details = $this->form_details;
		$messages = $this->messages;

	}

    /**
     *
     * As a protected function this will not be executed as a test
     * @param string $donation_method
     */
    protected function makeDonation($I, $organization, $donation_method,
		$donationPage, $civiCRMPage, $webmailPage, $loggedIn, $recurring)
    {

		//select relevant email
		if($donation_method == 'CreditCard') {
			if($recurring === false) {
				$this->form_details['email'] = EMAIL_CC;
				$this->form_details['email_pw'] = EMAIL_PW_CC;
			}
			elseif($recurring === true) {
				$this->form_details['email'] = EMAIL_RECUR_CC;
				$this->form_details['email_pw'] = EMAIL_PW_RECUR_CC;
			}
		}
		elseif($donation_method == 'PayPal' && $organization == 'TVP') {
			if($recurring === false) {
				$this->form_details['email'] = EMAIL_PP;
				$this->form_details['email_pw'] = EMAIL_PW_PP;
			}
			elseif($recurring === true) {
				$this->form_details['email'] = EMAIL_RECUR_PP;
				$this->form_details['email_pw'] = EMAIL_PW_RECUR_PP;
			}
		}
		elseif($donation_method == 'PayPal' && $organization == 'FBD') {
			if($recurring === false) {
				$this->form_details['email'] = EMAIL_FBD_PP;
				$this->form_details['email_pw'] = EMAIL_PW_FBD_PP;
			}
			elseif($recurring === true) {
				$this->form_details['email'] = EMAIL_FBD_RECUR_PP;
				$this->form_details['email_pw'] = EMAIL_PW_FBD_RECUR_PP;
			}
		}
        else {
            $email = TEST_EMAIL;
        }

        $I->fillDonationForm($organization, $donation_method, $this->form_details, $this->messages, $loggedIn, $recurring);
        $donation_datetime = $I->grabTextFrom($donationPage::$donation_datetime_selector);

		//todo: grab transaction ID. Note: for recurring payments with credit card it won't show the correct transaction ID, so we can skip that case until that is fixed. See https://github.com/drastik/com.drastikbydesign.stripe/issues/110

		//Need to first log out if we have been logged in as a regular user
		if($loggedIn === true) {
			$I->logOut();
		}

		$I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
        $I->checkDonationInBackend($donation_method, $civiCRMPage, $donation_datetime, $this->form_details, $this->messages, $recurring);
        $I->checkDonationInEmail($organization, $donation_method, $webmailPage, $donation_datetime, $this->form_details, $this->messages, $recurring);
    }   
}
