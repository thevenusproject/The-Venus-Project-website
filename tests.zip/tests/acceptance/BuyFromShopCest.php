<?php
use \AcceptanceTester;

class BuyFromShopCest
{
    public $form_details = array(
        'eBook_title' => "The Best That Money Can't Buy (eBook)",
        'eBook_price' => '$10.00',
        'billing_first_name' => 'Myfirstname',
        'billing_last_name' => 'Mylastname',
        'billing_address' => 'Myaddress',
        'billing_city' => 'Mycity',
        'billing_country' => 'United States',
        'billing_country_short' => 'US',
        'billing_state' => 'Florida',
        'billing_state_short' => 'Fl',
        'billing_postcode' => '33131',
        'billing_phone' => '12345678',
        'credit_card_number' => '4242424242424242',
        'credit_card_number_part_1' => '4242',
        'cvv2' => '111',
        'exp_date_m' => '02',
        'exp_date_y' => '18',
        'amount' => '$10.00',
        'email' => TEST_EMAIL,
        'email_pw' => EMAIL_PASSWORD,
    );

    public function _before(AcceptanceTester $I)
    {
    }

    public function _after(AcceptanceTester $I)
    {
    }

    /**
     * This code will be executed if a test fails or has errors
     * @param \AcceptanceTester $I
     */
    public function _failed(\Step\Acceptance\Admin $I)
    {
        $I->amGoingTo('Activate maintanance mode again');
        $I->activateMaintenanceMode($I);
    }

    // tests

    public function buyDigitalProductAsLoggedInWithPayPal(\Step\Acceptance\Admin $I, \Page\Webmail $webmailPage, \Page\Store $storePage)
    {
        $this->form_details['paypal_order_description'] = $this->form_details['eBook_title'];

        $I->amGoingTo('buy a digital product as a logged in user and pay wth PayPal');

        $I->logIn(TEST_USERNAME, TEST_PASSWORD);

        // go to shop url
        $I->amOnUrl(TEST_URL . '/store');

        // empty the cart if needed
        $this->emptyCart($I);

        $this->buyProduct($I, 'ebook', 'PayPal', $webmailPage, $storePage);

    }

    public function buyDigitalProductAsLoggedInWithCreditCard(\Step\Acceptance\Admin $I, \Page\Webmail $webmailPage, \Page\Store $storePage)
    {
        $this->form_details['paypal_order_description'] = $this->form_details['eBook_title'];

        $I->amGoingTo('buy a digital product as a logged in user and pay wth Credit Card');

        $I->logIn(TEST_USERNAME, TEST_PASSWORD);

        // go to shop url
        $I->amOnUrl(TEST_URL . '/store');

        $this->buyProduct($I, 'ebook', 'CreditCard', $webmailPage, $storePage);

    }

    public function buyDigitalProductAsLoggedOut(\Step\Acceptance\Admin $I)
    {
    }

    public function buyPhysicalProductAsLoggedIn(\Step\Acceptance\Admin $I)
    {
//        $this->form_details['paypal_order_description'] = $this->form_details['eBook_title'];
//
//        $I->amGoingTo('buy a physical product as a logged in user');
//
//        $I->logIn(TEST_USERNAME, TEST_PASSWORD);
//
//        // go to shop url
//        $I->amOnUrl(TEST_URL . '/store');
//
//        // empty the cart if needed
////        $this->emptyCart($I);
//
//        $this->buyProduct($I, 'book');
    }

    public function buyPhysicalProductAsLoggedOut(\Step\Acceptance\Admin $I)
    {
    }

    protected function buyProduct(\Step\Acceptance\Admin $I, $product, $payment_method, $webmailPage, $storePage)
    {
        $form_details = $this->form_details;

        //select relevant email
//		if($payment_method == 'CreditCard') {
//            $form_details['email'] = EMAIL_CC;
//            $form_details['email_pw'] = EMAIL_PW_CC;
//		}
//		elseif($payment_method == 'PayPal') {
//            $form_details['email'] = EMAIL_PP;
//            $form_details['email_pw'] = EMAIL_PW_PP;
//		}
//        else {
//            $email = TEST_EMAIL;
//        }

        if($product == 'ebook') {
            // click books
            $I->waitForElement(['xpath' => "//ul[@class='products']/li[2]/a"], 5);
            $I->click(['xpath' => "//ul[@class='products']/li[2]/a"]);

            // click ebook
            $I->click(['xpath' => "//ul[@class='products']/li/a"]);

            // verify the product info on the details page
            $I->canSee($form_details['eBook_price'], ['class' => 'price']);

            // empty the cart if needed
            $this->emptyCart($I);

            // click add to cart
            $I->click(['xpath' => "//form[@class='cart']/button"]);

            // see message
            // this fails bc of htmlentity problem? Or word-style quotes?
    //        $I->canSee("\"The Best That Money Can't Buy (eBook)\" has been added to your cart.", ['class' => 'woocommerce-message']);

            // check cart contents in sidebar
            $I->waitForElement(['class' => 'product_list_widget'], 5);
            $I->canSee($form_details['eBook_title'], ['class' => 'product_list_widget']);
            $I->canSee($form_details['eBook_price'], ['xpath' => "//p[@class='total']/span[@class='amount']"]);

            // click view cart
            $I->click(['xpath' => "//div[@class='widget_shopping_cart_content']/p[2]/a[1]"]);

            // verify cart contents
            $I->waitForElement(['id' => 'content']);
            $I->canSee($form_details['eBook_title'], ['xpath' => "//td[@class='product-name']"]);
            $I->canSee($form_details['eBook_price'], ['xpath' => "//td[@class='product-price']"]);
            $I->canSee($form_details['eBook_price'], ['xpath' => "//td[@class='product-subtotal']"]);


            // todo: try update card content

            // click proceed to checkout
            $I->click('Proceed to Checkout');

            // todo: test coupon code

            // fill in billing details
            $I->fillField(['id' => 'billing_first_name'], $form_details['billing_first_name']);
            $I->fillField(['id' => 'billing_last_name'], $form_details['billing_last_name']);
            $I->fillField(['id' => 'billing_email'], $form_details['email']);
            $I->fillField(['id' => 'billing_phone'], $form_details['billing_phone']);
            $I->fillField(['id' => 'billing_address_1'], $form_details['billing_address']);

            $I->fillField(['id' => 'billing_postcode'], $form_details['billing_postcode']);
            $I->fillField(['id' => 'billing_city'], $form_details['billing_city']);

            // todo: find a way to select country and state.
            //Select country. Since we use the Chosen plugin for the dropdown, there are a couple of additional steps.
            //Click on the dropdown
//            $I->click(['id' => 'select2-chosen-1']);
//
//            //Fill in country name. This input field becomes visible only after we have clicked on the dropdown above.
//            $I->fillField(['id' => 's2id_autogen1_search'], $form_details['billing_country']);
//
//            //Press enter
//            $I->pressKey(['id' => 's2id_autogen1_search'], \Facebook\WebDriver\WebDriverKeys::ENTER);
//
//            //The Provinces are dynamically loaded after country selection, so give it some time
//            // todo: target a spacific element to wait for, so we not always wait the full 10 seconds
//            $I->wait(10);
//
//            //Select State/Province
//            $I->click(['id' => 'select2-chosen-490']);
//            $I->fillField(['id' => 's2id_autogen2_search'], $form_details['billing_state']);
//            $I->pressKey(['id' => 's2id_autogen2_search'], \Facebook\WebDriver\WebDriverKeys::ENTER);

            // check order content
            $I->canSee($form_details['eBook_title'], ['xpath' => "//td[@class='product-name']"]);
            $I->canSee($form_details['eBook_price'], ['xpath' => "//td[@class='product-total']"]);

            // todo: check total


        }
        if($payment_method == 'PayPal') {
            // select paypal as payment
            $I->waitForElement(['id' => 'payment_method_paypal'], 5);
            $I->selectOption(['id' => 'payment_method_paypal'], 'paypal');
            $I->waitForText('Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.', 5, ['class' => 'payment_method_paypal']);
            $I->canSee('Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.', ['class' => 'payment_method_paypal']);

            // click proceed to paypal
            $I->click('Proceed to PayPal');

            $I->checkOrderOnPayPalWebsite();

            $I->payOrderOnPayPalWebsite(false, $form_details, null);
        }

        if($payment_method == 'CreditCard') {
            // select credit card as payment
            $I->waitForElement(['id' => 'payment_method_stripe'], 5);
            $I->selectOption(['id' => 'payment_method_stripe'], 'stripe');
            $I->waitForText('Pay with your credit card.', 5, ['class' => 'payment_method_stripe']);
            $I->canSee('Pay with your credit card.', ['class' => 'payment_method_stripe']);

            // click continue to payment
            $I->waitForElement(['id' => 'place_order'], 10);
            $I->click(['id' => 'place_order']);

            $I->wait(5);

            // fill in credit card in iframe
            $I->switchToIFrame("stripe_checkout_app");
            $I->pressKey(['id' => 'card_number'], $form_details['credit_card_number_part_1']);
            $I->pressKey(['id' => 'card_number'], $form_details['credit_card_number_part_1']);
            $I->pressKey(['id' => 'card_number'], $form_details['credit_card_number_part_1']);
            $I->pressKey(['id' => 'card_number'], $form_details['credit_card_number_part_1']);
            $I->pressKey(['id' => 'cc-exp'], $form_details['exp_date_m']);
            $I->pressKey(['id' => 'cc-exp'], $form_details['exp_date_y']);
            $I->fillField(['id' => 'cc-csc'], $form_details['cvv2']);

            $I->click(['id' => 'submitButton']);



        }

//        $I->pauseExecution();
        $this->checkOrderDetailsOnTVPConfirmationPage($I, $payment_method, $form_details, $storePage);

        // check order in admin
        $I->checkOrderInBackend($payment_method, $form_details);

        // check order in email
        $I->checkOrderInEmail($payment_method, $form_details, $webmailPage);
    }

    protected function checkOrderDetailsOnTVPConfirmationPage($I, $payment_method, $form_details, $storePage) {
        // check order details on tvp website
        $I->waitForText('Order Received', 15, ['class' => 'entry-header']);
        // todo: any assertions for this page
        $I->canSee($form_details['eBook_title'], ['xpath' => "//div[@class='woocommerce']/table/tbody/tr/td[1]"]);
        $I->canSee($form_details['email'], ['xpath' => "//div[@class='woocommerce']/table[2]/tbody/tr/td"]);
        $I->canSee($form_details['billing_phone'], ['xpath' => "//div[@class='woocommerce']/table[2]/tbody/tr[2]/td"]);

        $I->canSee($form_details['billing_address'], ['xpath' => "//address"]);

        if($payment_method == 'CreditCard') {
            $I->canSee('Credit card', $storePage::$order_payment_method_selector);
        }
        else {
            $I->canSee('PayPal', $storePage::$order_payment_method_selector);
        }

        // to do: test download file
        // check download link on order confirmation page
//            $I->click(['xpath' => "//td[@class='product-name']/small/a"]);
    }

    /**
     * For some reason after a test fails, the cart contents are still present.
     * For now we use this function to recursively remove all items from the cart
     */
    protected function emptyCart(\Step\Acceptance\Admin $I) {
        if($I->canSeePageHasElement(['xpath' => "//li[@class='mini_cart_item']/a[@class='remove']"])) {
            $I->click(['xpath' => "//li[@class='mini_cart_item']/a[@class='remove']"]);
            $this->emptyCart($I);
        }
    }


    /* TODO: REFACTORING:
     * - use nice short functions
     * - move all assertions to the testsuite, but keep steps inside stepobjects
     * - find a way to pass a user and an order to the test
     */
    /**
     *
     * @param array $products [[category] => [productname]]
     */
    protected function addProductToCart($products) {
        // for each product, click category, click product, add product to cart
    }
    protected function checkCartContentsInSidebar($products) {}
    protected function checkCartContents($products) {}
    protected function selectPaymentMethod($payment_method) {}
}
