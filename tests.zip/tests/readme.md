#Codeception + Selenium for automated acceptance tests

##Installation and setup

Steps:  
1. Put codecept.phar in the root of your website.  
2. Clone https://bitbucket.org/edwinderidder/tvp_automated_test into the site’s root, in a directory called tests. Inside the repository create a directory called _output  
3. Download the Selenium driver from [here](http://www.seleniumhq.org/download/), under Selenium Standalone Server. Put the file wherever is convenient.  
4. In the site’s root, create a file called codeception.yml and give it the following content:

```

actor: Tester
paths:
   tests: tests
   log: tests/_output
   data: tests/_data
   helpers: tests/_support
settings:
   bootstrap: _bootstrap.php
   colors: false
   memory_limit: 1024M
modules:
   config:
       Db:
           dsn: ''
           user: ''
           password: ''
           dump: tests/_data/dump.sql
extensions:
#    enabled: [Codeception\Extension\Logger]
   enabled: [Codeception\Extension\Recorder]
   config:
       Codeception\Extension\Recorder:
           delete_successful: false
```
Then, on command line, navigate to the site’s root. Run `php codecept.phar build`. Every time you make some changes to the config files, you will need to build the classes again.

##Running tests

Right-click the Selenium driver, select Open with… and choose Java(TM) Platform SE Binary. You won't see anything, it will just run in the background.

You can use the run command to run all tests. To run a specific test from the acceptance folder, we can specify it like this: `php codecept.phar run tests/acceptance/DonationsCest.php:donateWithCreditCardAsLoggedIn --steps`. If it works, you will see a browser window opening after a few seconds

In tests/tvp_config.php are constants with sensitive details (ignored by git). The template for that file is tests/_tvp_config.php (not ignored by git).

##Explanation of our test code structure and workings
In \tests\acceptance\DonationsCest.php is the test suite for donations. Every public function will be run as a test. 

Then we have StepObjects and PageObjects. You can find them in /support. In the StepObjects we basically have parts of the test that we can reuse. The PageObjects are used for some of the xpath selectors. So any complex xpath selectors will be in the PageObject classes. 

##Debugging your tests
An easy way to test xpath selectors: In Firebug, in the console, you can enter for example `$x("//table[@class='classname']")`, and when you press enter you will see a result in the console. Similarly, you can test CSS selectors by going to the CSS panel and trying your selector, e.g. `#crm-event_receipt > tbody > tr > td p`. 

In the _output dir you get a folder for each time you run a test. Inside that folder are screenshots and an index.html file. Open the html file to get a slideshow of the screenshots with further info on top of them.

As an alternative to var_dump you can use `\Codeception\Util\Debug::debug($my_var);`, but it works only if you add the --debug flag when running a test.
                 
##Notes & Resources 
Documentation of methods: http://codeception.com/docs/modules/WebDriver

We had a test running successfully, but after updating the selenium driver to the latest version the test was failing (more correctly, we got inconsistent behavior). It seems that such things can happen after a selenium or firefox update.

You can stop the selenium driver from running by entering this in your browser: http://localhost:4444/selenium-server/driver/?cmd=shutDownSeleniumServer

Writing reliable locators for Selenium and WebDriver tests: https://blog.mozilla.org/webqa/2013/09/26/writing-reliable-locators-for-selenium-and-webdriver-tests/