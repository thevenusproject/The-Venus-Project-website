<?php
// This is global bootstrap for autoloading

include 'tvp_config.php';