<?php
namespace Page;

class CiviCRM
{
    // include url of current page
    public static $URL = '';

    /**
     * Declare UI map for this page here. CSS or XPath allowed.
     * public static $usernameField = '#username';
     * public static $formSubmitButton = "#mainForm input[type=submit]";
     */
    public static $contribution_search_view_button = "//div[@class='crm-search-results']/table/tbody/tr[1]/td[11]/span/a[1]";
    public static $customer_name_selector = "//table[@class='crm-info-panel']/tbody/tr[1]/td[2]";
    public static $customer_amount_selector = "//table[@class='crm-info-panel']/tbody/tr[3]/td[2]";
	public static $customer_fee_selector = "//table[@class='crm-info-panel']/tbody/tr[4]/td[2]";
	public static $customer_net_amount_selector = "//table[@class='crm-info-panel']/tbody/tr[5]/td[2]";
    public static $customer_datetime_selector = "//table[@class='crm-info-panel']";
    public static $customer_details_selector = "//div[@class='form-item']";
    public static $status_completed_selector = "//table[@class='crm-info-panel']/tbody/tr[8]/td[2]";

    /**
     * Basic route example for your current URL
     * You can append any additional parameter to URL
     * and use it in tests like: Page\Edit::route('/123-post');
     */
    public static function route($param)
    {
        return static::$URL.$param;
    }


}
