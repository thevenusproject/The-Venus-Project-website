<?php
namespace Page;

class Donation
{
    // include url of current page
    public static $URL = '/donate';

    /**
     * Declare UI map for this page here. CSS or XPath allowed.
     * public static $usernameField = '#username';
     * public static $formSubmitButton = "#mainForm input[type=submit]";
     */
    public static $donation_datetime_selector = "//div[@class='crm-group amount_display-group']/div[2]/strong[2]";

    /**
     * Basic route example for your current URL
     * You can append any additional parameter to URL
     * and use it in tests like: Page\Edit::route('/123-post');
     */
    public static function route($param)
    {
        return static::$URL.$param;
    }


}
