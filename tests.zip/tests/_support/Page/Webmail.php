<?php
namespace Page;

class Webmail
{
    // include url of current page
    public static $URL = '';

    /**
     * Declare UI map for this page here. CSS or XPath allowed.
     * public static $usernameField = '#username';
     * public static $formSubmitButton = "#mainForm input[type=submit]";
     */
    public static $email_amount_selector = "//div[@class='rcmBody']/center[2]/table[2]/tbody/tr[2]/td[2]";
    public static $email_donation_datetime_selector = "//div[@class='rcmBody']/center[2]/table[2]/tbody/tr[3]/td[2]";
    public static $email_customer_details_selector = "//div[@class='rcmBody']/center[2]/table[2]/tbody/tr[6]/td";
	public static $email_physical_address_selector = "//div[@id='messagebody']/div/div/center[2]";
    public static $order_product_title_selector = "//tr[@class='order_item']/td[1]";
    public static $order_product_quantity_selector = "//tr[@class='order_item']/td[2]";
    public static $order_product_price_selector = "//tr[@class='order_item']/td[3]";
    public static $order_subtotal_selector = "//div[@id='body_content_inner']/table/tfoot/tr[1]/td";
    public static $order_payment_method_selector = "//div[@id='body_content_inner']/table/tfoot/tr[3]/td";
    public static $order_email_selector = "//div[@id='body_content_inner']/p[2]";
    public static $order_tel_selector = "//div[@id='body_content_inner']/p[3]";


    /**
     * Basic route example for your current URL
     * You can append any additional parameter to URL
     * and use it in tests like: Page\Edit::route('/123-post');
     */
    public static function route($param)
    {
        return static::$URL.$param;
    }


}
