<?php
namespace Codeception\Module;

// here you can define custom actions
// all public methods declared in helper class will be available in $I

class AcceptanceHelper extends \Codeception\Module
{

    /**
     * Checks if an element is in the page. Returns true if element present.
     *
     * @param type $element
     * @return boolean
     */
    public function canSeePageHasElement($element)
    {
        try {
            $this->getModule('WebDriver')->seeElement($element);
        } catch (\PHPUnit_Framework_AssertionFailedError $f) {
            return false;
        }
        return true;
    }

    /**
     * Checks if a string of text is on the page. Returns true if element present.
     *
     * @param string $text
     * @return boolean
     */
    public function canSeePageHasText($text)
    {
        try {
            $this->getModule('WebDriver')->see($text);
        } catch (\PHPUnit_Framework_AssertionFailedError $f) {
            return false;
        }
        return true;
    }

    /**
     * Checks if an element has one of two possible values
     *
     * @param string $element
     * @param string $value1
     * @param string $value2
     * @return boolean
     */
    public function canSeeElementHasOneOfTwoValues($value1, $value2, $element = null) {
        $result = true;
		$value1_result = true;
		$value2_result = true;
		
        try {
            $this->getModule('WebDriver')->see($value1, $element);
        } catch (\PHPUnit_Framework_AssertionFailedError $f) {
            $value1_result = false;
        }

        try {
            $this->getModule('WebDriver')->see($value2, $element);
        } catch (\PHPUnit_Framework_AssertionFailedError $f) {
            $value2_result = false;
        }

		if(($value1_result === false) && ($value2_result === false)) {
			$result = false;
		}
		
		$message = "{$value1} or {$value2} is present in ";
		$message .= ($element === null ? "the whole page" : $element);
		
        $this->assertTrue($result, $message);
    }

	/**
     * Checks if all paragraphs in an array are present in an element
     *
     * @param string $element
     * @param array $array1
     */
    public function canSeeMultipleParagraphs($array1, $element) {

        try {
			$array2 = $this->getModule('WebDriver')->grabMultiple($element);
        } catch (\PHPUnit_Framework_AssertionFailedError $f) {
			$this->fail("Failed running grabMultiple()");
        }
		
		//uncomment the debug() methods if you are debugging this
		// \Codeception\Util\Debug::debug($array2);		
		$difference = array_diff($array1, $array2);
		// \Codeception\Util\Debug::debug($difference);
		$this->assertEmpty($difference, "All paragraphs found");
    }
}