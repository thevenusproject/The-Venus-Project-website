<?php
namespace Step\Acceptance;

class Admin extends User
{

    /**
     * Login to the backend, if the user is not logged in already
     *
     * @param string $name
     * @param string $password
     */
    public function loginAsAdmin($name, $password)
    {
        $I = $this;
        $I->amOnUrl(TEST_URL . BACKEND_URL);

        $I->wait(5);
        if($I->canSeePageHasElement(['id' => 'loginform'])) {
            $I->fillField(['id' => 'user_login'], $name);
            $I->fillField(['id' => 'user_pass'], $password);
            $I->click(['id' => 'wp-submit']);
        }
    }

	/**
     * Log out of the site
     *
     * Note: Assumes we are logged in
     */
	public function logOutAsAdmin()
	{
		$I = $this;
        $I->amOnUrl(TEST_URL . BACKEND_URL);
		$I->moveMouseOver(['id' => 'wp-admin-bar-my-account']);
		$I->click(['xpath' => "//li[@id='wp-admin-bar-logout']/a"]);
	}

	/**
	* Activates the Maintenance Mode
	*
	* We need this function while in development to use the site as a logged out user
	*/
	public function activateMaintenanceMode($I)
	{
		$I->amOnUrl(TEST_URL . BACKEND_URL . '/options-general.php?page=seedprod_maintenance_mode');

		if(!$I->canSeePageHasElement(['id' => 'wp-admin-bar-debug-bar']) && !$I->canSeePageHasText('Maintenance Mode Active')) {
            $I->click(['xpath' => "//input[@name='seedprod_maintenancemode_options[maintenance_enabled][]']"]);
            // $I->click('Save Changes'); - worked in Firefox < 43
			$I->executeJS("document.getElementsByName('Submit')[0].click();");
		}
	}

	/**
	* Deactivates the Maintenance Mode
	*
	* We need this function while in development to use the site as a logged out user
	*/
	public function deactivateMaintenanceMode($I)
	{
		$I->amOnUrl(TEST_URL . BACKEND_URL . '/options-general.php?page=seedprod_maintenance_mode');

		if($I->canSeePageHasElement(['id' => 'wp-admin-bar-debug-bar']) && $I->canSeePageHasText('Maintenance Mode Active')) {
            $I->click(['xpath' => "//input[@name='seedprod_maintenancemode_options[maintenance_enabled][]']"]);
            // $I->click('Save Changes'); - worked in Firefox < 43
			$I->executeJS("document.getElementsByName('Submit')[0].click();");
		}
	}

    /**
     * Go to backend and checks the donation
     * Note: assumes user already logged in
     *
     * @param string $donation_datetime
     */
    public function checkDonationInBackend($payment_method, $civiCRMPage, $donation_datetime, $form_details, $messages, $recurring)
    {
        $I = $this;
        // go to admin to verify the test contribution was added
        // on localhost it would be better to look directly in the database
        $I->amOnUrl(TEST_URL . '/wp-admin/admin.php?page=CiviCRM&q=civicrm%2Fcontribute%2Fsearch&_qf_Search_display=true');
        $I->waitForElement(['id' => 'Search'], 10);

        $I->fillField(['id' => 'sort_name'], $form_details['email']);
        
		// select yes for Contribution is a test
        // $I->selectOption(['id' => 'CIVICRM_QFID_1_contribution_test'], '1'); - worked in Firefox < 43.0
		$I->executeJS("document.getElementById('CIVICRM_QFID_1_contribution_test').checked = true;");
        // click search
        $I->click(['id' => '_qf_Search_refresh']);
        $I->waitForElement(['id' => 'contributionSearch'], 10);
        // check if we see a record with the datetime we saw when we submitted the form
        $I->canSee($donation_datetime, ['id' => 'contributionSearch']);

        // click the view button, this clicks the view button in the first record
        // $I->click($civiCRMPage::$contribution_search_view_button); - worked in Firefox < 43.0
		$I->executeJS("document.evaluate(\"{$civiCRMPage::$contribution_search_view_button}\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click();");
        // todo: use xpath, to select the view button in the row where we can see the correct datetime, not sure why this line does not work:
        //$I->click(['xpath' => "//div[@id='contributionSearch']/table/tbody/tr[contains(td[7], '{$donation_datetime}')]/td[11]/span/a[1]"]);

        // check contents
        $I->waitForElement(['class' => 'crm-info-panel'], 10);
        $I->canSeeElementHasOneOfTwoValues("{$form_details['billing_first_name']} {$form_details['billing_last_name']}", $form_details['email'], $civiCRMPage::$customer_name_selector);
        $I->canSee($form_details['amount'], $civiCRMPage::$customer_amount_selector);

		if($recurring === true) {
			//interval will change to 1 month when we move to production
			$I->canSee('Recurring Contribution', $civiCRMPage::$customer_amount_selector);
			$I->canSee('Installments: (ongoing), Interval: 1 month(s)', $civiCRMPage::$customer_amount_selector);
		}

		//check fee
		$fee = $I->calculateDonationFee($form_details['amount']);
		$I->canSee($fee, $civiCRMPage::$customer_fee_selector);

		//check net amount
		$net_amount = $form_details['amount'] - $fee;
		$I->canSee($net_amount, $civiCRMPage::$customer_net_amount_selector);

        $I->canSee($donation_datetime, $civiCRMPage::$customer_datetime_selector);

        //check that contribution status is completed
        $I->canSee($messages['contrib_status_completed'], $civiCRMPage::$status_completed_selector);

        if($payment_method != 'PayPal') {
            $I->canSeeElementHasOneOfTwoValues("{$form_details['billing_first_name']} {$form_details['billing_last_name']}", $form_details['email'], $civiCRMPage::$customer_details_selector);
            $I->canSee("{$form_details['billing_first_name']} {$form_details['billing_last_name']}", $civiCRMPage::$customer_details_selector);
            $I->canSee($form_details['billing_street'], $civiCRMPage::$customer_details_selector);
            $I->canSee($form_details['billing_city'], $civiCRMPage::$customer_details_selector);
            $I->canSee($form_details['billing_state_short'], $civiCRMPage::$customer_details_selector);
            $I->canSee($form_details['billing_postal_code'], $civiCRMPage::$customer_details_selector);
            $I->canSee($form_details['billing_country'], $civiCRMPage::$customer_details_selector);
        }


		if($recurring === true) {
			//todo: go to the user's profile and check that the recurring contribution details are OK
			//this will need to be done when the stripe extension is fixed
		}
    }

	/**
	* Calculates the payment gateway fee
	*
	* Note: assumes we are donating using US dollars. Otherwise there are additional fees.
	*/
	protected function calculateDonationFee($donation_amount) {

		//Stripe pricing: https://stripe.com/us/pricing
		//Paypal pricing: https://www.paypal.com/webapps/mpp/merchant-fees
		$percentage = 2.9;
		$hard_fee = 0.30;

		$fee_after_percentage = ($donation_amount * $percentage) / 100;
		$final_fee = $fee_after_percentage + $hard_fee;
		return $final_fee;
	}

    /**
     * check the submitted order in the backend
     */
    public function checkOrderInBackend($payment_method, $form_details) {
        $I = $this;
        $I->loginAsAdmin(ADMIN_USERNAME, ADMIN_PASSWORD);
        $I->amOnUrl(TEST_URL . BACKEND_URL . '/edit.php?post_type=shop_order');
        $I->waitForElement(['xpath' => "//tbody[@id='the-list']"]);

        // assume the order is on the first table row
        $I->canSee($form_details['email'], ['xpath' => "//tbody[@id='the-list']/tr[1]"]);
        $I->canSee($form_details['billing_address'], ['xpath' => "//tbody[@id='the-list']/tr[1]"]);
        // click view button
        $I->click(['xpath' => "//tbody[@id='the-list']/tr[1]/td[9]/p/a"]);
        $I->waitForElement(['id' => 'order_data']);

        if($payment_method == 'CreditCard') {
            $I->canSee('Payment via Credit Card', ['id' => 'order_data']);
        }

        // check general details
        $I->canSee('Completed', ['xpath' => "//div[@class='order_data_column_container']/div[1]"]);

        // check billing details
        $I->canSee($form_details['billing_address'], ['xpath' => "//div[@class='order_data_column_container']/div[2]"]);
        $I->canSee($form_details['email'], ['xpath' => "//div[@class='order_data_column_container']/div[2]"]);
        $I->canSee($form_details['billing_phone'], ['xpath' => "//div[@class='order_data_column_container']/div[2]"]);

        // check shipping details
        $I->canSee($form_details['billing_phone'], ['xpath' => "//div[@class='order_data_column_container']/div[2]"]);

        // check order items
        $I->canSee($form_details['eBook_title'], ['xpath' => "//tbody[@id='order_line_items']/tr[1]"]);
    }

}