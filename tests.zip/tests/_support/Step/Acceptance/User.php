<?php
namespace Step\Acceptance;

class User extends \AcceptanceTester
{
	/**
	* Log in as regular user
	*/
	public function logIn($name, $password)
	{
		$I = $this;
        $I->amOnUrl(TEST_URL . '/wp-login.php');
        $I->waitForElement(['id' => 'loginform'], 5);
        $I->fillField(['id' => 'user_login'], $name);
        $I->fillField(['id' => 'user_pass'], $password);
        $I->click(['id' => 'wp-submit']);
	}

	/**
	* Log out as regular user
	*/
	public function logOut()
	{
		$I = $this;
        $I->amOnUrl(TEST_URL . '/wp-login.php?action=logout');
        $I->waitForElement(['id' => 'error-page'], 5);
        $I->click(['xpath' => '//html/body/p[2]/a']);
	}

    /**
     * Log in to the webmail account
     */
    public function loginToWebmail($form_details) {
        $I = $this;

        $I->amOnUrl('https://www.thevenusproject.com/webmail');
        $I->fillField(['id' => 'user'], $form_details['email']);
        $I->fillField(['id' => 'pass'], $form_details['email_pw']);

        $I->click(['id' => 'login_submit']);

        $I->waitForElement(['id' => 'roundcube_cell'], 5);
        $I->click('#roundcube_cell a');
    }

    /**
     *
     */
    public function fillDonationForm($organization, $payment_method, $form_details, $messages, $loggedIn, $recurring)
    {
        $I = $this;

        // Go to donation page
		if($organization == 'TVP') {
			$I->amOnUrl(TEST_URL . '/donations/research-center/');
			$I->waitForElement(['id' => 'credit_card_number'], 20);
			$I->canSee('Donate to the Research Center', ['class' => 'entry-title']);
			$I->canSeeMultipleParagraphs($messages['donation_page_tvp'], '#intro_text p');
		}
		elseif($organization == 'FBD') {
			$I->amOnUrl(TEST_URL . '/donations/motion-picture/');
			$I->waitForElement(['id' => 'priceset-div'], 20);
			$I->canSee('Donate for the Major Motion Picture', ['class' => 'entry-title']);
			$I->canSeeMultipleParagraphs($messages['donation_page_fbd'], '#intro_text p');
		}
$I->pauseExecution();
		//check "Not you or want to do this for different person?" message. can be refactored later
		if($loggedIn === true) {
			$I->canSeeElementHasOneOfTwoValues("{$form_details['billing_first_name']} {$form_details['billing_last_name']}",
               $form_details['email'],
               "//div[@class='messages status no-popup crm-not-you-message']");
			$I->canSee('Welcome ', ['class' => 'crm-not-you-message']);
			$I->canSee('want to do this for a different person?)', ['class' => 'crm-not-you-message']);
		}

		//check that the default donation amount is already selected
		$I->canSeeOptionIsSelected(['class' => 'contribution_amount-content'], '10.00');

		//select our desired amount
        $I->selectOption(['class' => 'contribution_amount-content'], $form_details['amount']);

		if($recurring === true) {
			//check the recurring option
			$I->checkOption(['id' => 'is_recur']);
			// select monthly recurring
			$I->selectOption(['id'=>'frequency_unit'], 'month');

			//give it a couple of seconds
			$I->wait(2);

			//see that recurring contribution message is shown
			$I->canSee('Your recurring contribution will be processed automatically. You will receive an email receipt for each recurring contribution.', ['id' => 'recurHelp']);
		}

		if($loggedIn === true) {
			//for some reason the below line does not work for me
			//check that the email field is filled in
			//$I->canSee(TEST_EMAIL, ['id' => 'email-5']);
		}
		elseif($loggedIn === false) {
			// fill in email field
			$I->fillField(['id' => 'email-5'], $form_details['email']);
		}

		if($organization == 'TVP') {
			// on this donation page we have two processors, so assert that credit card is selected
			$I->canSeeOptionIsSelected(['class' => 'payment_processor-section'], 'Credit Card');
		}

        if($payment_method == 'CreditCard') {
            // enter credit card details
            $I->fillField(['id' => 'credit_card_number'], $form_details['credit_card_number']);
            $I->fillField(['id' => 'cvv2'], $form_details['cvv2']);
            $I->selectOption(['id' => 'credit_card_exp_date_M'], $form_details['exp_date_m']);
            $I->selectOption(['id' => 'credit_card_exp_date_Y'], $form_details['exp_date_y']);

            // enter billing information
            $I->fillField(['id' => 'billing_first_name'], $form_details['billing_first_name']);
            $I->fillField(['id' => 'billing_last_name'], $form_details['billing_last_name']);
            $I->fillField(['id' => 'billing_street_address-5'], $form_details['billing_street']);
            $I->fillField(['id' => 'billing_city-5'], $form_details['billing_city']);

            //Select country. Since we use the Chosen plugin for the dropdown, there are a couple of additional steps.
            //Click on the dropdown
            $I->click(['id' => 'select2-chosen-1']); //sometimes it clicks on the static menu instead
			// $I->executeJS("document.getElementById('select2-chosen-1').click();"); - this doesn't work for some reason

            //Fill in country name. This input field becomes visible only after we have clicked on the dropdown above.
            $I->fillField(['id' => 's2id_autogen1_search'], $form_details['billing_country']);

            //Press enter
            $I->pressKey(['id' => 's2id_autogen1_search'], \Facebook\WebDriver\WebDriverKeys::ENTER);

            //The Provinces are dynamically loaded after country selection, so give it some time
            // todo: target a spacific element to wait for, so we not always wait the full 10 seconds
            $I->wait(10);

            //Select State/Province
            $I->click(['id' => 'select2-chosen-2']);
            $I->fillField(['id' => 's2id_autogen2_search'], $form_details['billing_state']);
            $I->pressKey(['id' => 's2id_autogen2_search'], \Facebook\WebDriver\WebDriverKeys::ENTER);

            //Fill in Postal Code
            $I->fillField(['id' => 'billing_postal_code-5'], $form_details['billing_postal_code']);

            // click confirm contribution
            // $I->click(['id' => '_qf_Main_upload-bottom']); - worked in Firefox < 43
			$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

            $I->amGoingTo('Check the details on the confirmation page');

            // verify we are now on the confirmation page
            $I->waitForElement(['id' => 'Confirm'], 10);
            $I->canSeeInCurrentUrl('civicrm/contribute/transact&_qf_Confirm');

            // verify details on confirmation page
            $I->canSee($form_details['amount'], ['class' => 'amount_display-group']);

			if($recurring === true) {
				//see confirmation about recurring contribution
				$I->canSee('I want to contribute this amount every month.', ['class' => 'amount_display-group']);
				$I->canSee($messages['recurring_info_msg'], ['class' => 'amount_display-group']);
			}

            $I->canSee("{$form_details['billing_first_name']} {$form_details['billing_last_name']}", ['class' => 'billing_name-section']);
            $I->canSee($form_details['billing_street'], ['class' => 'billing_address-section']);
            $I->canSee($form_details['billing_city'], ['class' => 'billing_address-section']);
            $I->canSee($form_details['billing_postal_code'], ['class' => 'billing_address-section']);
            $I->canSee($form_details['billing_state_short'], ['class' => 'billing_address-section']);
            $I->canSee($form_details['billing_country_short'], ['class' => 'billing_address-section']);

            $I->canSee($form_details['email'], ['class' => 'contributor_email-section']);

            // verify we see the message here (This line does not work for me)
    //        $I->canSee('Your contribution will not be completed until you click the Make Contribution button. Please click the button one time only. ', ['class' => 'continue_instructions-section']);

            // click make contribution button
            // $I->click(['id' => '_qf_Confirm_next-bottom']); - worked in Firefox < 43
			$I->executeJS("document.getElementById('_qf_Confirm_next-bottom').click();");
        }

        elseif($payment_method == 'PayPal') {

			if($organization == 'TVP') {
				// select PayPal option
				$I->selectOption(['class' => 'payment_processor-section'], 'Paypal');
			}

//            $I->waitForElementChange($element, $callback, $timeout);
            // or:
            $I->waitForElementNotVisible(['class' => 'billing_name_address-group'], 10);

            // assert that form fields for billing name etc are not present on the page
            $I->cantSeeElement(['class' => 'billing_mode-group']);
            $I->cantSeeElement(['class' => 'billing_name_address-group']);

            // click confirm contribution
            // $I->click(['id' => '_qf_Main_upload-bottom']); - worked in Firefox < 43
			$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

            // assert we get the donate page with summary (amount, email)
            $I->waitForElement(['class' => 'amount_display-group'], 10);
            $I->canSee($form_details['amount'], ['class' => 'amount_display-group']);
            $I->canSee($form_details['email'], ['class' => 'contributor_email-section']);

			if($recurring === true) {
				//see confirmation about recurring contribution
				$I->canSee('I want to contribute this amount every month.', ['class' => 'amount_display-group']);
				$I->canSee($messages['recurring_info_msg'], ['class' => 'amount_display-group']);
			}

            // click continue
            // $I->click(['id' => '_qf_Confirm_next-bottom']); - worked in Firefox < 43
			$I->executeJS("document.getElementById('_qf_Confirm_next-bottom').click();");
			
            $this->payOnPayPalWebsite($recurring, $form_details, $messages);

        } //end elseif($payment_method == 'PayPal')

			$I->amGoingTo('Check the details on the Thankyou page');

            // Verify that you end up on Thank You page
			$I->waitForElement(['id' => 'thankyou_text']);

			if($payment_method == 'CreditCard') {
				$I->canSeeInCurrentUrl('civicrm/contribute/transact&_qf_ThankYou');
			}
			elseif($payment_method == 'PayPal') {
				$I->canSeeInCurrentUrl('civicrm%2fcontribute%2ftransact&_qf_ThankYou'); // note: %2f in url instead of /
			}

			//check our own thank you text for the thank you page
			$I->canSee($messages['page_thank_you_msg'][0], ['id' => 'thankyou_text']);
			$I->canSee($messages['page_thank_you_msg'][1], ['id' => 'thankyou_text']);
			$I->canSee($messages['page_thank_you_msg'][2], ['id' => 'thankyou_text']);

			//check the Civi standard text for the thank you page
			if($recurring === true || $payment_method == 'PayPal') {
				$I->canSee('Your contribution has been submitted for processing. Please print this page for your records.', ['xpath' => "//div[@id='help']/div[1]"]);
				$I->canSee("An email receipt will be sent to " . $form_details['email'] . " once the transaction is processed successfully. If you don't find this email in your inbox, please look for it in your Spam folder.", ['id' => 'help']);
			}
			elseif($recurring === false && $payment_method == 'CreditCard') {
				$I->canSee('Your transaction has been processed successfully. Please print this page for your records.', ['id' => 'help']);
				$I->canSee("An email receipt has also been sent to " . $form_details['email'] . ". If you don't find this email in your inbox, please look for it in your Spam folder.", ['id' => 'help']);
			}

            // verify again the correct details are shown
            $I->canSee($form_details['amount'], ['class' => 'amount_display-group']);

			if($recurring === true) {
				$I->canSee('This recurring contribution will be automatically processed every month.', ['class' => 'amount_display-group']);
				$I->canSee('You will receive an email receipt which includes information about how to update or cancel this recurring contribution.', ['class' => 'amount_display-group']);
			}

			if($payment_method == 'CreditCard') {
				$I->canSee("{$form_details['billing_first_name']} {$form_details['billing_last_name']}", ['class' => 'billing_name-section']);
				$I->canSee($form_details['billing_street'], ['class' => 'billing_address-section']);
				$I->canSee($form_details['billing_city'], ['class' => 'billing_address-section']);
				$I->canSee($form_details['billing_postal_code'], ['class' => 'billing_address-section']);
				$I->canSee($form_details['billing_state_short'], ['class' => 'billing_address-section']);
				$I->canSee($form_details['billing_country_short'], ['class' => 'billing_address-section']);
				//todo: check credit card type and expiration date
			}

            $I->canSee($form_details['email'], ['class' => 'contributor_email-section']);

    }

    /**
     * Logs into webmail, and checks if the email was received and has the correct content
     *
     * @param string $donation_datetime
     */
    public function checkDonationInEmail($organization, $payment_method, $webmailPage, $donation_datetime, $form_details, $messages, $recurring) {
        // Check that correct payment details are sent to the donor by email
        // Right now we login to a webmail account
        // another way would be to use something like MailCatcher
        $I = $this;

        $I->amOnUrl('https://www.thevenusproject.com/webmail');
        $I->fillField(['id' => 'user'], $form_details['email']);
        $I->fillField(['id' => 'pass'], $form_details['email_pw']);

        $I->click(['id' => 'login_submit']);

        $I->waitForElement(['id' => 'roundcube_cell'], 5);
        $I->click('#roundcube_cell a');
		$I->waitForElement(['xpath' => "//table[@id='messagelist']/tbody/tr[1]"], 10);

		//for recurring contributions with paypal we have an additional notification email
		//to add to the fun, it could be either the last or the one before the last email
		if($recurring === true && $payment_method == 'PayPal') {
			$last_subject = $I->grabTextFrom(['xpath' => "//table[@id='messagelist']/tbody/tr[1]/td[2]/a"]);

			if($last_subject == 'Recurring Contribution Notification') {
				$selector_notification = "//table[@id='messagelist']/tbody/tr[1]/td[2]/a";
				$selector_receipt = "//table[@id='messagelist']/tbody/tr[2]/td[2]/a";
			}
			elseif(strpos($last_subject, '[TEST]Receipt - Donate') !== false) {
				$selector_notification = "//table[@id='messagelist']/tbody/tr[2]/td[2]/a";
				$selector_receipt = "//table[@id='messagelist']/tbody/tr[1]/td[2]/a";
			}

			//open notification email and check header and content
			$this->openEmailInRoundcube($selector_notification);
			$I->canSee('Recurring Contribution Notification', ['xpath' => "//div[@id='messageheader']/h2"]);
			$I->canSee('This is an email to let you know that you have subscribed for a recurring contribution. You will receive an additional email which contains a receipt and an invoice with the details of the contribution you have made.', ['xpath' => "//table[@id='crm-event_receipt']/tbody/tr/td/p[1]"]);
			$I->canSee('If you would like to cancel or change the amount of this recurring contribution, please reply to this message or send an email to webmaster@thevenusproject.com.', ['xpath' => "//table[@id='crm-event_receipt']/tbody/tr[4]/td"]);

			//go back to the inbox
			$this->openEmailInRoundcube(['xpath' => "//ul[@id='mailboxlist']/li[1]/a"]);
			$I->waitForElement(['xpath' => "//table[@id='messagelist']/tbody/tr[1]"], 10);
		}

        // open receipt email
        if($recurring === true && $payment_method == 'PayPal') {
			$this->openEmailInRoundcube($selector_receipt);
		}
		else {
			// this targets the last recieved email, it should be the one we need
//			$I->doubleClick(['xpath' => "//table[@id='messagelist']/tbody/tr[1]/td[2]/a"]); // not works with firefox 43 and selenium 2.48.2
            $this->openEmailInRoundcube("//table[@id='messagelist']/tbody/tr[1]/td[2]/a");
		}

        //check email subject, thank you text and organization-specific physical address
		if($organization == 'TVP') {
			$I->canSee('[TEST]Receipt - Donate to the Research Center', ['xpath' => "//div[@id='messageheader']/h2"]);
			$I->canSeeMultipleParagraphs($messages['email_thank_you_msg_tvp'], '#crm-event_receipt > tbody > tr > td p');
			$I->canSee('The Venus Project', $webmailPage::$email_physical_address_selector);
			$I->canSee('admin@thevenusproject.com', $webmailPage::$email_physical_address_selector);
			$I->canSee('www.thevenusproject.com', $webmailPage::$email_physical_address_selector);
			$I->dontSee('fbd@futurebydesign.org');
			$I->dontSee('futurebydesign.org');
		}
		elseif($organization == 'FBD') {
			$I->canSee('[TEST]Receipt - Donate for the Major Motion Picture', ['xpath' => "//div[@id='messageheader']/h2"]);
			$I->canSeeMultipleParagraphs($messages['email_thank_you_msg_fbd'], '#crm-event_receipt > tbody > tr > td p');
			$I->canSee('Future by Design', $webmailPage::$email_physical_address_selector);
			$I->canSee('fbd@futurebydesign.org', $webmailPage::$email_physical_address_selector);
			$I->canSee('futurebydesign.org', $webmailPage::$email_physical_address_selector);
			$I->dontSee('admin@thevenusproject.com');
			$I->dontSee('www.thevenusproject.com');
		}

		//check physical address info common to both organizations
		$I->canSee('21 Valley Lane', $webmailPage::$email_physical_address_selector);
		$I->canSee('Venus, FL 33960', $webmailPage::$email_physical_address_selector);
		$I->canSee('United States', $webmailPage::$email_physical_address_selector);
		$I->canSee('+1863-465-0321', $webmailPage::$email_physical_address_selector);

        // check To
        $I->canSeeElementHasOneOfTwoValues("{$form_details['billing_first_name']} {$form_details['billing_last_name']}",
                $form_details['email'],
                "//td[@class='header to']/span/a");

        // check amount
        $I->canSee($form_details['amount'], $webmailPage::$email_amount_selector);
        // check date
        $I->canSee($donation_datetime, $webmailPage::$email_donation_datetime_selector);

		if($recurring === true) {
			$I->canSee('This is a recurring contribution. If you would like to cancel it or change the amount, please reply to this message or send an email to webmaster@thevenusproject.com.', ['xpath' => "//div[@class='rcmBody']/center[2]/table[2]/tbody"]);
		}

        // billing name and addres not present for recurring donations, and donations through paypal
		if($recurring === false && $payment_method != 'PayPal') {
            //todo: check transaction number

            //check billing name and address
            $I->canSee("{$form_details['billing_first_name']} {$form_details['billing_last_name']}", $webmailPage::$email_customer_details_selector);
            $I->canSee($form_details['billing_street'], $webmailPage::$email_customer_details_selector);
            $I->canSee($form_details['billing_city'], $webmailPage::$email_customer_details_selector);
            $I->canSee($form_details['billing_state_short'], $webmailPage::$email_customer_details_selector);
            $I->canSee($form_details['billing_postal_code'], $webmailPage::$email_customer_details_selector);
            $I->canSee($form_details['billing_country_short'], $webmailPage::$email_customer_details_selector);
		}

		//check spam message
		$I->canSee('Did you find this email in your Spam folder? If so, please mark it as Not Spam.', $webmailPage::$email_physical_address_selector);

        //check that the invoice and receipt are attached
        $I->canSee('Invoice.pdf', ['xpath' => "//ul[@id='attachment-list']/li[1]/a"]);
        $I->canSee('receipt.pdf', ['xpath' => "//ul[@id='attachment-list']/li[2]/a"]);

		// Grab the URL of the Invoice.pdf file and go to it
		$url = $I->grabAttributeFrom(['xpath' => "//ul[@id='attachment-list']/li[1]/a"], 'href');
		$I->amOnUrl($url);
		$I->wait(5);


		//Check values in the invoice PDF
        $I->canSeeElementHasOneOfTwoValues($form_details['billing_first_name'] . ' ' . $form_details['billing_last_name'], $form_details['email']);
        if($payment_method != 'PayPal') {
            $I->canSee($form_details['billing_street']);
            $I->canSee($form_details['billing_state_short']);
            $I->canSee($form_details['billing_city']);
            $I->canSee($form_details['billing_postal_code']);
        }

		$parts = explode(' ', $donation_datetime);
		$parts[1] = substr($parts[1], 0, -3); //trim last three characters
		$donation_datetime = $parts[0] . ' ' . $parts[1] . ', ' . $parts[2];

		$I->canSee($donation_datetime);
		$I->canSee('21 Valley Lane');
		$I->canSee('FL');
		$I->canSee('Venus 33960');
		$I->canSee('United States');
		$I->canSee('+18634650321');
		$I->canSee($form_details['amount']);
		$I->canSee('$ 0.00');  // amount due

		//if we donate to TVP
		if($organization == 'TVP') {
			$I->canSee('The Venus Project');
			$I->canSee('admin@thevenusproject.com');
			$I->dontSee('Future by Design');
			$I->dontSee('fbd@futurebydesign.org');
		}
		//if we donate to FBD
		elseif($organization == 'FBD') {
			$I->canSee('Future by Design');
			$I->canSee('fbd@futurebydesign.org');
			$I->dontSee('The Venus Project');
			$I->dontSee('admin@thevenusproject.com');
		}
    }

	public function tryDonation($I, $donationPage, $form_details)
    {
        $I->amOnUrl(TEST_URL . '/donations/research-center/');
		$I->waitForElement(['id' => 'credit_card_number'], 20);

		// click confirm contribution
        // $I->click(['id' => '_qf_Main_upload-bottom']); - worked in Firefox < 43
		$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

		//see error about incorrect CC number
		$I->waitForElement(['id' => 'errorList'], 5);
		$I->canSee('Payment Error Response:', ['xpath' => "//form[@id='Main']/div[1]/strong"]);
		$I->canSee('Error: This card number looks invalid.', ['xpath' => "//ul[@id='errorList']/li"]);

		//fill in card number
		//this card will eventually be declined by stripe.com. See https://stripe.com/docs/testing
		$I->fillField(['id' => 'credit_card_number'], '4000000000000002');
		$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

		//see error about invalid expiration year
		$I->waitForElement(['id' => 'errorList'], 5);
		$I->canSee('Payment Error Response:', ['xpath' => "//form[@id='Main']/div[1]/strong"]);
		$I->canSee("Error: Your card's expiration year is invalid.", ['xpath' => "//ul[@id='errorList']/li"]);

		//select expiration date
		$I->selectOption(['id' => 'credit_card_exp_date_M'], $form_details['exp_date_m']);
		$I->selectOption(['id' => 'credit_card_exp_date_Y'], $form_details['exp_date_y']);
		$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

		//see error about invalid security code
		$I->waitForElement(['id' => 'errorList'], 5);
		$I->canSee('Payment Error Response:', ['xpath' => "//form[@id='Main']/div[1]/strong"]);
		$I->canSee("Error: Your card's security code is invalid.", ['xpath' => "//ul[@id='errorList']/li"]);

		//fill in security code
		$I->fillField(['id' => 'cvv2'], $form_details['cvv2']);
		$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

		//see multiple errors
		$I->waitForElement(['id' => 'errorList'], 5);
		$I->canSee('Please correct the following errors in the form fields below:', ['xpath' => "//form[@id='Main']/div[2]"]);
		$I->canSee("Billing First Name is a required field.", ['xpath' => "//ul[@id='errorList']"]);
		$I->canSee("Billing Last Name is a required field.", ['xpath' => "//ul[@id='errorList']"]);
		$I->canSee("Street Address is a required field.", ['xpath' => "//ul[@id='errorList']"]);
		$I->canSee("City is a required field.", ['xpath' => "//ul[@id='errorList']"]);
		$I->canSee("Postal Code is a required field.", ['xpath' => "//ul[@id='errorList']"]);
		$I->canSee("Country is a required field.", ['xpath' => "//ul[@id='errorList']"]);
		$I->canSee("Email Address is a required field.", ['xpath' => "//ul[@id='errorList']"]);

		// enter billing information and country
		$I->fillField(['id' => 'billing_first_name'], $form_details['billing_first_name']);
		$I->fillField(['id' => 'billing_last_name'], $form_details['billing_last_name']);
		$I->fillField(['id' => 'billing_street_address-5'], $form_details['billing_street']);
		$I->fillField(['id' => 'billing_city-5'], $form_details['billing_city']);
		$I->click(['id' => 'select2-chosen-1']);
		$I->fillField(['id' => 's2id_autogen1_search'], $form_details['billing_country']);
		$I->pressKey(['id' => 's2id_autogen1_search'], \Facebook\WebDriver\WebDriverKeys::ENTER);
		$I->wait(10);
		$I->click(['id' => 'select2-chosen-2']);
		$I->fillField(['id' => 's2id_autogen2_search'], $form_details['billing_state']);
		$I->pressKey(['id' => 's2id_autogen2_search'], \Facebook\WebDriver\WebDriverKeys::ENTER);
		$I->fillField(['id' => 'billing_postal_code-5'], $form_details['billing_postal_code']);
		$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

		//see error message about missing email
		$I->waitForElement(['id' => 'errorList'], 5);
		$I->canSee('Please correct the following errors in the form fields below:', ['xpath' => "//form[@id='Main']/div[2]"]);
		$I->canSee("Email Address is a required field.", ['xpath' => "//ul[@id='errorList']"]);

		//enter incorrect email
		$I->fillField(['id' => 'email-5'], 'blahblah.com');
		$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

		//see error about invalid email
		$I->waitForElement(['id' => 'errorList'], 5);
		$I->canSee('Please correct the following errors in the form fields below:', ['xpath' => "//form[@id='Main']/div[2]"]);
		$I->canSee("Email is not valid.", ['xpath' => "//ul[@id='errorList']"]);

		//enter correct email
		$I->fillField(['id' => 'email-5'], 'email@example.com');
		$I->executeJS("document.getElementById('_qf_Main_upload-bottom').click();");

		// verify we are now on the confirmation page and attempt contribution
		$I->waitForElement(['id' => 'Confirm'], 10);
		$I->canSeeInCurrentUrl('civicrm/contribute/transact&_qf_Confirm');
		$I->executeJS("document.getElementById('_qf_Confirm_next-bottom').click();");

		//see error about declined card
		$I->waitForElement(['id' => 'credit_card_number'], 20);
		$I->canSee("Oops! Looks like there was an error. Payment Response:", ['xpath' => "//div[@id='crm-main-content-wrapper']/div/span[2]"]);
		$I->canSee("Type: card_error", ['xpath' => "//div[@id='crm-main-content-wrapper']/div/span[2]"]);
		$I->canSee("Code: card_declined", ['xpath' => "//div[@id='crm-main-content-wrapper']/div/span[2]"]);
		$I->canSee("Message: Your card was declined.", ['xpath' => "//div[@id='crm-main-content-wrapper']/div/span[2]"]);
    }

    public function checkDonationOnPaypalWebsite() {

    }

    public function checkOrderOnPayPalWebsite() {

    }

    public function payOnPayPalWebsite($recurring, $form_details, $messages) {
        $I = $this;
        // assert we are now at Paypal page
        if($recurring === true) {
            $I->waitForElement(['id' => 'xptContentContainer'], 10);
            $I->canSee(PAYPAL_STORE_NAME, ['id' => 'header']);

             // check order summary
            $I->canSee('Online Contribution: Donate', ['xpath' => "//div[@id='orderDetailsArea']/table/tbody/tr[2]/td[1]"]);
            // check terms
            $I->canSee('$'.$form_details['amount'].' USD for each month', ['xpath' => "//div[@id='orderDetailsArea']/table/tbody/tr[2]/td[2]"]);
            // check amount
            $I->canSee($form_details['amount'], ['xpath' => "//div[@id='orderDetailsArea']/table/tbody/tr[2]/td[3]"]);

            // select I already have a PayPal account, if needed
            if($I->canSeePageHasElement(['id' => 'billingInfo'])) {
                $I->click(['id' => 'payment_type_paypal']);
            }


            // enter PayPal login info
            $I->fillField(['id' => 'login_email'], PAYPAL_BUYER_ACCOUNT);
            $I->fillField(['id' => 'login_password'], PAYPAL_BUYER_ACCOUNT_PASSWORD);
            $I->click('Log In');
            $I->waitForElement(['id' => 'modularContent'], 10);

            // click Agree and Pay
            $I->click('Agree and Pay');

            // Verify that you end up on Thank You page
            $I->waitForElement(['id' => 'thankyou_text']);
            $I->canSeeInCurrentUrl('civicrm%2fcontribute%2ftransact&_qf_ThankYou');  // note: %2f in url instead of /

            // verify again the correct details are shown
            $I->canSee($form_details['amount'], ['class' => 'amount_display-group']);
            $I->canSee($form_details['email'], ['class' => 'contributor_email-section']);

            // verify message
            $I->canSee($messages['recurring_monthly_msg'], ['class' => 'amount_display-group']);
        }
        else {
            $I->waitForElement(['id' => 'sliders'], 10);
            $I->canSee(PAYPAL_STORE_NAME, ['id' => 'header']);

            $I->pauseExecution();

            // check order summary
            $I->canSee('Online Contribution: Donate', ['id' => 'multiitem1']);
            // check item price
            $I->canSee($form_details['amount'], ['xpath' => "//li[@id='multiitem1']/ul/li[2]"]);
            // check quantity
            $I->canSee('Quantity: 1', ['xpath' => "//li[@id='multiitem1']/ul/li[3]"]);
            $I->canSee($form_details['amount'], ['class' => 'grandTotal']);

            // activate the tab for Pay with PayPal account, if needed
            if($I->canSeePageHasElement(['id' => 'billingModule'])) {
                $I->click(['id' => 'loadLogin']);
                $I->waitForElement(['id' => 'loginModule'], 10);
            }

            // enter PayPal login info
            $I->fillField(['id' => 'login_email'], PAYPAL_BUYER_ACCOUNT);
            $I->fillField(['id' => 'login_password'], PAYPAL_BUYER_ACCOUNT_PASSWORD);
            $I->click(['id' => 'submitLogin']);

            $I->waitForElement(['id' => 'continueButtonSection'], 10);
            $I->canSee(PAYPAL_BUYER_ACCOUNT, ['id' => 'contactInfo']);

            // click Pay Now
            $I->click(['id' => 'continue']);

            $I->waitForElement(['id' => 'merchantredirectform'], 10);
            $I->canSee('Thanks for your order');

            // Verify that you end up on Thank You page
            $I->waitForElement(['id' => 'thankyou_text']);
            $I->canSeeInCurrentUrl('civicrm%2fcontribute%2ftransact&_qf_ThankYou');  // note: %2f in url instead of /

            // verify again the correct details are shown
            $I->canSee($form_details['amount'], ['class' => 'amount_display-group']);
            $I->canSee($form_details['email'], ['class' => 'contributor_email-section']);
        }
    }

    public function payOrderOnPayPalWebsite($recurring, $form_details, $messages) {
        $I = $this;
        $I->waitForElement(['id' => 'sliders'], 10);
        $I->canSee(PAYPAL_STORE_NAME, ['id' => 'header']);

        $I->pauseExecution();

        // check order summary
            $I->canSee($form_details['eBook_title'], ['id' => 'multiitem1']);
            // check item price
            $I->canSee($form_details['amount'], ['xpath' => "//li[@id='multiitem1']/ul/li[2]"]);
            // check quantity
            $I->canSee('Quantity: 1', ['xpath' => "//li[@id='multiitem1']/ul/li[3]"]);
            $I->canSee($form_details['amount'], ['class' => 'grandTotal']);

            // activate the tab for Pay with PayPal account, if needed
            if($I->canSeePageHasElement(['id' => 'billingModule'])) {
                $I->click(['id' => 'loadLogin']);
                $I->waitForElement(['id' => 'loginModule'], 10);
            }

            // enter PayPal login info
            $I->fillField(['id' => 'login_email'], PAYPAL_BUYER_ACCOUNT);
            $I->fillField(['id' => 'login_password'], PAYPAL_BUYER_ACCOUNT_PASSWORD);
            $I->click(['id' => 'submitLogin']);

            $I->waitForElement(['id' => 'continueButtonSection'], 10);
            $I->canSee(PAYPAL_BUYER_ACCOUNT, ['id' => 'contactInfo']);

            // click Pay Now
            $I->click(['id' => 'continue']);

            $I->waitForElement(['id' => 'merchantredirectform'], 10);
            $I->canSee('Thanks for your order');
    }


    public function checkOrderInEmail($payment_method, $form_details, $webmailPage) {
        $I = $this;
        $I->loginToWebmail($form_details);

        // open email
        // this targets the last recieved email, it should be the one we need
        $I->waitForElement(['id' => 'rcmsubject'], 5);
        $I->doubleClick(['xpath' => "//table[@id='messagelist']/tbody/tr/td/a"]);

        // check subject
        $date = date('F d, Y');
        $I->canSee("The Venus Project: Your order from {$date} is completed", '#messageheader h2');

        // check To
        $I->canSeeElementHasOneOfTwoValues("{$form_details['billing_first_name']} {$form_details['billing_last_name']}",
                $form_details['email'],
                "//td[@class='header to']/span/a");

        //check email thank you text
        $I->canSee('Your order is completed - download your files', ['id' => "template_header"]);

        $I->canSee($form_details['eBook_title'], $webmailPage::$order_product_title_selector);
        $I->canSee('1', $webmailPage::$order_product_quantity_selector);
        $I->canSee($form_details['eBook_price'], $webmailPage::$order_product_price_selector);

        if($payment_method == 'CreditCard') {
            $I->canSee('Credit card', $webmailPage::$order_payment_method_selector);
        }
        else {
            $I->canSee('PayPal', $webmailPage::$order_payment_method_selector);
        }


        $I->canSee($form_details['email'], $webmailPage::$order_email_selector);
        $I->canSee($form_details['billing_phone'], $webmailPage::$order_tel_selector);

        $I->canSee($form_details['billing_address'], ['id' => 'addresses']);
        $I->canSee($form_details['billing_postcode'], ['id' => 'addresses']);
        $I->canSee($form_details['billing_city'], ['id' => 'addresses']);
        // todo: fix check for country
//        $I->canSee($form_details['billing_country'], ['id' => 'addresses']);

    }

    /**
     * This replaces the doubleClick() function that stopped working
     * It assumes you are on the homepage, with the list of emails
     *
     * @param string $selector
     */
    protected function openEmailInRoundcube($selector) {
        $I = $this;
        $href = $I->grabAttributeFrom($selector, 'href');
        $url = $I->executeJS('window.location');
        // strip "./?_task=mail" from href
        $href = str_replace('./?_task=mail', '', $href);
        // append stripped href to current url
        $link_to_email = $url.$href;
        $I->amOnUrl($link_to_email);
    }

}